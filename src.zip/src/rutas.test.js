import {
  crearRuta,
  eliminarRuta,
  obtenerZonas,
  obtenerRutasPorZona,
  resetRutas,
  editarRuta,
  obtenerTodasRutas,
  existeRuta
} from "./rutas.js";

describe("HU6 - Crear ruta por zona", () => {

  beforeEach(() => {
    resetRutas();
  });

  test("debería crear una ruta correctamente", () => {
    crearRuta("norte", "Av. América");

    const rutas = obtenerRutasPorZona("norte");

    expect(rutas.length).toBe(1);
    expect(rutas[0].ruta).toBe("Av. América");
  });

  
  test("debería eliminar una ruta", () => {
    crearRuta("norte", "Av. América");

    eliminarRuta("norte", "Av. América");

    const rutas = obtenerRutasPorZona("norte");

    expect(rutas.length).toBe(0);
  });

});

describe("HU7 - Ver ruta por zona", () => {

  beforeEach(() => {
    resetRutas();
  });

  test("debería devolver rutas de una zona existente", () => {
    crearRuta("norte", "Ruta 1");

    const rutas = obtenerRutasPorZona("norte");

    expect(rutas.length).toBe(1);
  });

  test("debería lanzar error si la zona es inválida", () => {
    expect(() => obtenerRutasPorZona("   ")).toThrow();
  });

  test("debería ignorar mayúsculas/minúsculas en la zona", () => {
    crearRuta("Norte", "Ruta 1");

    const rutas = obtenerRutasPorZona("norte");

    expect(rutas.length).toBe(1);
  });

  test("debería ignorar espacios en la zona al buscar", () => {
    crearRuta("norte", "Ruta 1");

    const rutas = obtenerRutasPorZona(" norte ");

    expect(rutas.length).toBe(1);
  });

  test("debería editar el nombre de una ruta existente", () => {
    crearRuta("norte", "Ruta Antigua");
    editarRuta("norte", "Ruta Antigua", "Ruta Nueva");
    const rutas = obtenerRutasPorZona("norte");
    expect(rutas[0].ruta).toBe("Ruta Nueva");
  });

  test("debería lanzar error si el nuevo nombre de ruta está vacío", () => {
    crearRuta("norte", "Ruta 1");

    expect(() => {
        editarRuta("norte", "Ruta 1", "");
    }).toThrow("Datos incompletos");
  });


  test("la ruta antigua no debe existir después de la edición", () => {
    crearRuta("norte", "Ruta A");
    editarRuta("norte", "Ruta A", "Ruta B");

    const rutas = obtenerRutasPorZona("norte");
    const existeVieja = rutas.some(r => r.ruta === "Ruta A");
    
    expect(existeVieja).toBe(false);
  });

});
describe("SP2-04 - Soporte para enlazar rutas y horarios", () => {
  beforeEach(() => {
    resetRutas();
  });

  test("debería obtener todas las rutas disponibles para programación", () => {
    crearRuta("norte", "Ruta 1");
    crearRuta("sur", "Ruta 2");

    const rutas = obtenerTodasRutas();

    expect(rutas.length).toBe(2);
    expect(rutas[0].ruta).toBe("Ruta 1");
    expect(rutas[1].ruta).toBe("Ruta 2");
  });

  test("debería verificar si una ruta existe", () => {
    crearRuta("norte", "Ruta 1");

    const resultado = existeRuta("Ruta 1");

    expect(resultado).toBe(true);
  });

  test("debería devolver falso si la ruta no existe", () => {
    crearRuta("norte", "Ruta 1");

    const resultado = existeRuta("Ruta 99");

    expect(resultado).toBe(false);
  });

  test("debería verificar la ruta ignorando mayúsculas, minúsculas y espacios", () => {
    crearRuta("norte", "Ruta 1");

    const resultado = existeRuta("  ruta 1  ");

    expect(resultado).toBe(true);
  });
});